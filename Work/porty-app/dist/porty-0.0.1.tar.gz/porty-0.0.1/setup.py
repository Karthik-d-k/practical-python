# setup.py

import setuptools

setuptools.setup(
    name="porty",
    version="0.0.1",
    author="Karthik D K",
    author_email="karthikdk1998@gmail.com",
    description="Practical Python Code",
    packages=setuptools.find_packages(),
)
